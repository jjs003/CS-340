# -*- coding: utf-8 -*-
"""
Created on Fri Jul 26 10:23:33 2024

@author: jeremy_snhu
"""

from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, user:str, password:str):
        # Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        # This is hard-wired to use the AAC database, the
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = user
        PASS = password
        HOST = 'localhost'
        PORT = 27017
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
 
    # "Create" method to implement the C in CRUD.
    # Inserts a document into the animals collection.
    def create(self, data:dict) -> bool:
        if data:
            try:
                self.collection.insert_one(data)  # data should be dictionary
                return True
            except Exception as e:
                print(f"An error occurred while inserting the document: {e}\n" \
                      "Please check the provided data for errors and try again.")
                return False
        else:
            print("Nothing to save, because data parameter is empty.")
            return False

    # "Read" method to implement the R in CRUD.
    # Returns a list of the query results or an empty list if there are no results
    def read(self, query:dict) -> list:
        try:
            cursor = self.collection.find(query)
            results = list(cursor)
            if not results:
                print("Your query did not return any results.")
            return results
        except Exception as e:
            print(f"An error occurred while querying the documents: {e}\n" \
                  "Please check your query and try again.")
            return []
        
    # Update method to implement the U in CRUD.
    # Queries for and updates document(s) in the animals collection.    
    def update(self, query: dict, update_values: dict) -> int:
        if query and update_values:
            try:
                result = self.collection.update_many(query, {'$set': update_values})
                return result.modified_count
            except Exception as e:
                print(f"An error occurred while updating the documents: {e}")
                return 0
        else:
                print("Query and update_values parameters must not be empty.")
                return 0
            
    # Delete method to implement the D in CRUD.
    # Queries for and removes document(s) from the animals collection.
    def delete(self, query: dict) -> int:
        if query:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except Exception as e:
                print(f"An error occurred while deleting the documents: {e}")
                return 0
        else:
                print("Query parameter must not be empty.")
                return 0
